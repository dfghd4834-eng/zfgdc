package com.example.operastream

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.*
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView

class MainActivity : Activity() {
    private lateinit var player: ExoPlayer
    private lateinit var urlField: EditText
    private lateinit var status: TextView
    private lateinit var playerView: PlayerView
    private lateinit var videoBox: FrameLayout
    private var fullscreen = false
    private val ink = Color.rgb(9, 12, 26)
    private val muted = Color.rgb(169, 178, 205)
    private val white = Color.WHITE
    private val violet = Color.rgb(115, 91, 255)

    private fun dp(n: Int) = (n * resources.displayMetrics.density).toInt()
    private fun shape(color: Int, radius: Int = 24, stroke: Int? = null): GradientDrawable =
        GradientDrawable().apply {
            setColor(color); cornerRadius = dp(radius).toFloat()
            stroke?.let { setStroke(dp(1), it) }
        }
    private fun gradient(vararg colors: Int, radius: Int = 24): GradientDrawable =
        GradientDrawable(GradientDrawable.Orientation.TL_BR, colors).apply { cornerRadius = dp(radius).toFloat() }
    private fun label(text: String, size: Float, color: Int = white, bold: Boolean = false): TextView =
        TextView(this).apply {
            this.text = text; textSize = size; setTextColor(color)
            if (bold) setTypeface(null, Typeface.BOLD)
            gravity = Gravity.CENTER_VERTICAL
        }
    private fun column(): LinearLayout = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
    private fun row(): LinearLayout = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
    private fun margin(top: Int = 0, bottom: Int = 0) = LinearLayout.LayoutParams(-1, -2).apply {
        topMargin = dp(top); bottomMargin = dp(bottom)
    }
    private fun button(text: String, background: android.graphics.drawable.Drawable, click: () -> Unit): TextView =
        label(text, 15f, white, true).apply {
            gravity = Gravity.CENTER; this.background = background
            setPadding(dp(16), dp(15), dp(16), dp(15)); setOnClickListener { click() }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = ink
        window.navigationBarColor = ink
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
        val loadControl = DefaultLoadControl.Builder()
            .setBufferDurationsMs(15000, 50000, 1000, 2000).build()
        player = ExoPlayer.Builder(this).setLoadControl(loadControl).build()
        buildUi()
        player.addListener(object : Player.Listener {
            override fun onPlaybackStateChanged(state: Int) {
                status.text = when (state) {
                    Player.STATE_BUFFERING -> "◌  جاري تجهيز الفيديو…"
                    Player.STATE_READY -> "●  الفيديو جاهز للتشغيل"
                    Player.STATE_ENDED -> "✓  انتهى الفيديو"
                    else -> "جاهز لاستقبال رابط"
                }
            }
            override fun onPlayerError(error: PlaybackException) {
                status.text = "تعذر التشغيل. تأكد أن الرابط مباشر وصالح."
                Toast.makeText(this@MainActivity, "تعذر تشغيل الرابط أو أن الخادم يمنع الوصول", Toast.LENGTH_LONG).show()
            }
        })
        handleIntent(intent)
    }

    private fun buildUi() {
        val root = FrameLayout(this).apply {
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR,
                intArrayOf(Color.rgb(24, 24, 58), ink, Color.rgb(11, 19, 38)))
        }
        val scroll = ScrollView(this).apply { fillViewport = true; clipToPadding = false }
        val content = column().apply { setPadding(dp(20), dp(32), dp(20), dp(32)) }
        scroll.addView(content)
        root.addView(scroll)

        val top = row()
        val emblem = label("▶", 22f, white, true).apply {
            gravity = Gravity.CENTER
            background = gradient(violet, Color.rgb(46, 167, 244), radius = 18)
        }
        top.addView(emblem, LinearLayout.LayoutParams(dp(54), dp(54)))
        val titleGroup = column().apply { setPadding(dp(12), 0, 0, 0) }
        titleGroup.addView(label("OperaStream", 25f, white, true))
        titleGroup.addView(label("مشغل فيديو بتصميم زجاجي", 12f, muted))
        top.addView(titleGroup)
        content.addView(top, margin(bottom = 28))

        content.addView(label("شاهد بدون تعقيد.", 29f, white, true))
        content.addView(label("الصق رابط الفيديو وشغّله فورًا قدر الإمكان.", 14f, muted), margin(top = 7, bottom = 22))

        val glass = column().apply {
            setPadding(dp(16), dp(17), dp(16), dp(16))
            background = shape(Color.argb(105, 48, 54, 92), 26, Color.argb(85, 205, 211, 255))
        }
        glass.addView(label("رابط الفيديو", 15f, white, true), margin(bottom = 10))
        urlField = EditText(this).apply {
            hint = "https://example.com/video.m3u8"
            setHintTextColor(Color.rgb(128, 139, 174))
            setTextColor(white); textSize = 14f
            setSingleLine(true); inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
            background = shape(Color.argb(165, 12, 17, 36), 15)
            setPadding(dp(14), dp(15), dp(14), dp(15))
            setText(getPreferences(MODE_PRIVATE).getString("last_url", ""))
        }
        glass.addView(urlField, margin(bottom = 13))
        val actions = row()
        val playButton = button("▶  تشغيل الآن", gradient(violet, Color.rgb(55, 132, 246), radius = 16)) {
            play(urlField.text.toString())
        }
        actions.addView(playButton, LinearLayout.LayoutParams(0, -2, 1f))
        val pasteButton = button("لصق", shape(Color.argb(140, 92, 99, 139), 16)) {
            val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            val pasted = clipboard.primaryClip?.getItemAt(0)?.coerceToText(this)?.toString().orEmpty()
            urlField.setText(pasted); urlField.setSelection(urlField.length())
        }
        actions.addView(pasteButton, LinearLayout.LayoutParams(-2, -2).apply { leftMargin = dp(9) })
        glass.addView(actions)
        content.addView(glass)

        val videoCard = column().apply {
            setPadding(dp(12), dp(12), dp(12), dp(12))
            background = shape(Color.argb(135, 32, 38, 71), 26, Color.argb(65, 210, 214, 255))
        }
        val videoHeader = row()
        videoHeader.addView(label("المشغل", 16f, white, true), LinearLayout.LayoutParams(0, -2, 1f))
        videoHeader.addView(label("HD  •  HLS", 12f, Color.rgb(153, 192, 255), true))
        videoCard.addView(videoHeader, margin(bottom = 12))
        videoBox = FrameLayout(this).apply { background = shape(Color.BLACK, 18); clipToOutline = true }
        playerView = PlayerView(this).apply {
            player = this@MainActivity.player
            useController = true
            resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FIT
            setShowBuffering(PlayerView.SHOW_BUFFERING_ALWAYS)
            setShutterBackgroundColor(Color.BLACK)
        }
        videoBox.addView(playerView, FrameLayout.LayoutParams(-1, -1))
        videoCard.addView(videoBox, LinearLayout.LayoutParams(-1, 0).apply { height = dp(200) })
        status = label("جاهز لاستقبال رابط", 13f, muted)
        videoCard.addView(status, margin(top = 12, bottom = 8))
        videoCard.addView(button("⛶  ملء الشاشة", shape(Color.argb(140, 68, 76, 122), 14)) { toggleFullscreen() })
        content.addView(videoCard, margin(top = 18))

        val note = column().apply {
            setPadding(dp(17), dp(16), dp(17), dp(16))
            background = shape(Color.argb(95, 52, 62, 96), 20)
        }
        note.addView(label("✦  تشغيل ذكي", 16f, white, true))
        note.addView(label("يدعم MP4 و M3U8 و DASH. يضبط جودة HLS تلقائيًا عندما يوفر الخادم مستويات متعددة. سرعة البدء تعتمد على الإنترنت والخادم.", 13f, muted), margin(top = 8))
        note.addView(label("ملاحظة: رابط صفحة موقع ليس دائمًا رابط فيديو مباشرًا.", 12f, Color.rgb(195, 196, 219)), margin(top = 9))
        content.addView(note, margin(top = 18))
        setContentView(root)
    }

    private fun play(raw: String) {
        val url = Regex("https?://[^\\s]+", RegexOption.IGNORE_CASE).find(raw.trim())?.value ?: ""
        if (url.isEmpty()) {
            Toast.makeText(this, "أدخل رابط فيديو يبدأ بـ http أو https", Toast.LENGTH_SHORT).show()
            return
        }
        getPreferences(MODE_PRIVATE).edit().putString("last_url", url).apply()
        val item = MediaItem.Builder().setUri(url).apply {
            val path = url.substringBefore('?').lowercase()
            if (path.endsWith(".m3u8")) setMimeType(MimeTypes.APPLICATION_M3U8)
            if (path.endsWith(".mpd")) setMimeType(MimeTypes.APPLICATION_MPD)
        }.build()
        player.setMediaItem(item)
        player.prepare()
        player.playWhenReady = true
        status.text = "◌  جاري الاتصال بالخادم…"
    }

    private fun toggleFullscreen() {
        fullscreen = !fullscreen
        if (fullscreen) {
            requestedOrientation = android.content.pm.ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
            window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY)
        } else {
            requestedOrientation = android.content.pm.ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
            window.decorView.systemUiVisibility = 0
        }
        val params = videoBox.layoutParams as LinearLayout.LayoutParams
        params.height = if (fullscreen) resources.displayMetrics.heightPixels - dp(80) else dp(200)
        videoBox.layoutParams = params
    }
    private fun handleIntent(i: Intent?) {
        val text = when (i?.action) {
            Intent.ACTION_SEND -> i.getStringExtra(Intent.EXTRA_TEXT)
            Intent.ACTION_VIEW -> i.dataString
            else -> null
        } ?: return
        val url = Regex("https?://[^\\s]+", RegexOption.IGNORE_CASE).find(text)?.value ?: return
        urlField.setText(url)
        play(url)
    }
    override fun onNewIntent(intent: Intent) { super.onNewIntent(intent); setIntent(intent); handleIntent(intent) }
    override fun onStop() { super.onStop(); player.pause() }
    override fun onDestroy() { player.release(); super.onDestroy() }
}
