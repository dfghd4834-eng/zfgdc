package com.moulay.smoothplayer

import android.app.Activity
import android.app.AlertDialog
import android.app.PictureInPictureParams
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.OpenableColumns
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.app.Dialog
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.*
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import java.security.MessageDigest

class MainActivity : Activity() {

    private lateinit var player: ExoPlayer
    private lateinit var videoView: PlayerView
    private lateinit var status: TextView
    private lateinit var cover: TextView
    private lateinit var controls: LinearLayout

    private var videoUri: Uri? = null
    private var subtitleUri: Uri? = null
    private var subtitleMime = MimeTypes.APPLICATION_SUBRIP
    private var coverEnabled = true
    private var smoothMode = true

    private val skipRanges = mutableListOf<Pair<Long, Long>>()
    private val coverRanges = mutableListOf<Pair<Long, Long>>()
    private val handler = Handler(Looper.getMainLooper())

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun glass() = GradientDrawable().apply {
        setColor(Color.argb(170, 46, 61, 89))
        cornerRadius = dp(19).toFloat()
        setStroke(dp(1), Color.argb(115, 225, 235, 255))
    }

    private fun newPlayer(): ExoPlayer {
        val lc = if (smoothMode)
            DefaultLoadControl.Builder().setBufferDurationsMs(15000, 60000, 1500, 3000).build()
        else DefaultLoadControl.Builder().build()
        return ExoPlayer.Builder(this).setLoadControl(lc).build()
    }

    private val checker = object : Runnable {
        override fun run() {
            if (::player.isInitialized) {
                val t = player.currentPosition
                if (player.isPlaying) {
                    skipRanges.firstOrNull { t >= it.first && t < it.second }
                        ?.let { player.seekTo(it.second) }
                }
                cover.visibility =
                    if (coverEnabled && coverRanges.any { t >= it.first && t < it.second })
                        View.VISIBLE else View.GONE
            }
            handler.postDelayed(this, 250)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(9, 14, 26)
        window.navigationBarColor = Color.rgb(9, 14, 26)
        player = newPlayer()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(16), dp(12), dp(8))
            setBackgroundColor(Color.rgb(9, 14, 26))
        }
        root.addView(TextView(this).apply {
            text = "✦ سلاسة"
            textSize = 29f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        })
        status = TextView(this).apply {
            text = "مشغل فيديو عالي السلاسة"
            textSize = 13f
            gravity = Gravity.CENTER
            setTextColor(Color.rgb(180, 205, 235))
            setPadding(0, dp(7), 0, dp(12))
        }
        root.addView(status)

        val frame = FrameLayout(this)
        videoView = PlayerView(this).apply {
            player = this@MainActivity.player
            useController = true
            keepScreenOn = true
            setBackgroundColor(Color.BLACK)
        }
        frame.addView(videoView, FrameLayout.LayoutParams(-1, -1))
        cover = TextView(this).apply {
            text = "تم حجب هذا المشهد"
            textSize = 22f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.rgb(12, 18, 31))
            visibility = View.GONE
        }
        frame.addView(cover, FrameLayout.LayoutParams(-1, -1))
        root.addView(frame, LinearLayout.LayoutParams(-1, 0, 1f))

        val scroll = ScrollView(this)
        controls = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(controls)
        root.addView(scroll, LinearLayout.LayoutParams(-1, dp(300)))

        addButton("📁 فتح فيديو من الجوال") { pickFile(100, "video/*") }

        addButton("🌐 تشغيل رابط HTTPS") {
            showInput("رابط الفيديو", "https://") { text ->
                val uri = Uri.parse(text)
                if (uri.scheme == "https" && !uri.host.isNullOrBlank()) {
                    videoUri = uri
                    subtitleUri = null
                    loadRanges()
                    playVideo(0L)
                } else status.text = "الرابط غير صالح"
            }
        }

        addButton("🌐 متصفح مدمج لموقع من اختيارك") { openBrowser() }

        addButton("📝 إضافة ترجمة SRT / VTT") { pickFile(101, "*/*") }

        addButton("⚡ وضع التشغيل السلس") {
            smoothMode = !smoothMode
            status.text = if (smoothMode) "التخزين المؤقت الموسع مفعل" else "التشغيل العادي"
            val pos = player.currentPosition
            val was = player.playWhenReady
            player.release()
            player = newPlayer()
            videoView.player = player
            playVideo(pos)
            player.playWhenReady = was
        }

        addButton("🛡️ تخطي مشهد غير مناسب") { addRange(skipRanges, "التخطي") }
        addButton("🙈 حجب مشهد غير مناسب") { addRange(coverRanges, "الحجب") }

        addButton("👁️ تشغيل / إيقاف الحجب") {
            coverEnabled = !coverEnabled
            status.text = if (coverEnabled) "الحجب مفعل" else "الحجب متوقف"
        }

        addButton("🗑️ حذف فترات الحجب والتخطي") {
            skipRanges.clear()
            coverRanges.clear()
            saveRanges()
            cover.visibility = View.GONE
            status.text = "تم حذف الفترات"
        }

        addButton("⛶ ملء الشاشة") {
            @Suppress("DEPRECATION")
            window.decorView.systemUiVisibility =
                View.SYSTEM_UI_FLAG_FULLSCREEN or
                View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
        }

        addButton("▣ صورة داخل صورة") {
            try {
                enterPictureInPictureMode(PictureInPictureParams.Builder().build())
            } catch (e: Exception) {
                status.text = "الميزة غير متاحة"
            }
        }

        setContentView(root)
        handler.post(checker)
    }

    private fun addButton(label: String, action: () -> Unit) {
        val b = TextView(this).apply {
            text = label
            textSize = 15f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            background = glass()
            isFocusable = true
            isClickable = true
            setOnClickListener { action() }
        }
        controls.addView(b, LinearLayout.LayoutParams(-1, dp(50)).apply { bottomMargin = dp(8) })
    }

    private fun showInput(title: String, initial: String, onOk: (String) -> Unit) {
        val et = EditText(this).apply { setText(initial); setSingleLine() }
        AlertDialog.Builder(this)
            .setTitle(title)
            .setView(et)
            .setPositiveButton("موافق") { _, _ -> onOk(et.text.toString().trim()) }
            .setNegativeButton("إلغاء", null)
            .show()
    }

    private fun pickFile(code: Int, mime: String) {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = mime
        }
        try { startActivityForResult(i, code) } catch (e: Exception) {
            status.text = "لا يوجد تطبيق لاختيار الملفات"
        }
    }

    @Deprecated("Legacy activity result")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK) return
        val uri = data?.data ?: return

        if (requestCode == 100) {
            videoUri = uri
            subtitleUri = null
            loadRanges()
            playVideo(0L)
        }
        if (requestCode == 101 && videoUri != null) {
            subtitleUri = uri
            val name = contentResolver.query(
                uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null
            )?.use { c -> if (c.moveToFirst()) c.getString(0) else null }
                ?: uri.lastPathSegment.orEmpty()
            subtitleMime = if (name.lowercase().endsWith(".vtt"))
                MimeTypes.TEXT_VTT else MimeTypes.APPLICATION_SUBRIP
            playVideo(player.currentPosition.coerceAtLeast(0L))
        }
    }

    private fun playVideo(position: Long) {
        val uri = videoUri ?: return
        val b = MediaItem.Builder().setUri(uri)
        if (uri.toString().substringBefore("?").endsWith(".m3u8", true))
            b.setMimeType(MimeTypes.APPLICATION_M3U8)
        subtitleUri?.let { sub ->
            val cfg = MediaItem.SubtitleConfiguration.Builder(sub)
                .setMimeType(subtitleMime)
                .setLanguage("ar")
                .setSelectionFlags(C.SELECTION_FLAG_DEFAULT)
                .build()
            b.setSubtitleConfigurations(listOf(cfg))
        }
        player.setMediaItem(b.build())
        player.prepare()
        player.seekTo(position)
        player.play()
        status.text = "جارٍ التشغيل"
    }

    // ---------- متصفح مدمج ----------

    private fun openBrowser() {
        showInput("عنوان الموقع (https)", "https://") { text ->
            val u = if (text.startsWith("https://")) text
                    else "https://" + text.removePrefix("http://")
            val web = WebView(this).apply {
                settings.javaScriptEnabled = true
                settings.domStorageEnabled = true
                webViewClient = WebViewClient()
            }
            val dlg = Dialog(this, android.R.style.Theme_Material_NoActionBar)
            val bar = LinearLayout(this).apply {
                setBackgroundColor(Color.rgb(9, 14, 26))
                setPadding(dp(8), dp(8), dp(8), dp(8))
            }
            fun barBtn(t: String, a: () -> Unit) = TextView(this).apply {
                text = t
                textSize = 14f
                gravity = Gravity.CENTER
                setTextColor(Color.WHITE)
                background = glass()
                setOnClickListener { a() }
            }.also { bar.addView(it, LinearLayout.LayoutParams(0, dp(44), 1f).apply { marginEnd = dp(6) }) }
            barBtn("◀ رجوع") { if (web.canGoBack()) web.goBack() }
            barBtn("▶ شغّل في المشغّل") {
                val cur = web.url ?: ""
                val path = cur.substringBefore("?").lowercase()
                if (cur.startsWith("https://") &&
                    listOf(".mp4", ".m3u8", ".webm", ".mkv").any { path.endsWith(it) }) {
                    videoUri = Uri.parse(cur)
                    subtitleUri = null
                    loadRanges()
                    dlg.dismiss()
                    playVideo(0L)
                } else Toast.makeText(this, "الصفحة الحالية ليست رابط فيديو مباشر", Toast.LENGTH_LONG).show()
            }
            barBtn("✖ إغلاق") { dlg.dismiss() }
            val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            col.addView(bar)
            col.addView(web, LinearLayout.LayoutParams(-1, 0, 1f))
            dlg.setContentView(col)
            dlg.setOnKeyListener { _, code, ev ->
                if (code == KeyEvent.KEYCODE_BACK && ev.action == KeyEvent.ACTION_UP) {
                    if (web.canGoBack()) web.goBack() else dlg.dismiss()
                }
                code == KeyEvent.KEYCODE_BACK
            }
            dlg.setOnDismissListener { web.destroy() }
            dlg.show()
            web.loadUrl(u)
        }
    }

    // ---------- فترات التخطي والحجب ----------

    private fun parseTime(s: String): Long? {
        val p = s.trim().split(":").map { it.trim().toLongOrNull() ?: return null }
        val sec = when (p.size) {
            1 -> p[0]
            2 -> p[0] * 60 + p[1]
            3 -> p[0] * 3600 + p[1] * 60 + p[2]
            else -> return null
        }
        return sec * 1000
    }

    private fun fmt(ms: Long): String {
        val t = ms / 1000
        val h = t / 3600
        val m = (t % 3600) / 60
        val s = t % 60
        return if (h > 0) "%d:%02d:%02d".format(h, m, s) else "%02d:%02d".format(m, s)
    }

    private fun addRange(list: MutableList<Pair<Long, Long>>, name: String) {
        if (videoUri == null) { status.text = "افتح فيديو أولًا"; return }
        val now = fmt(player.currentPosition)
        showInput("$name: اكتب البداية-النهاية مثل 01:20-02:05", "$now-$now") { text ->
            val p = text.split("-")
            val a = if (p.size == 2) parseTime(p[0]) else null
            val b = if (p.size == 2) parseTime(p[1]) else null
            if (a != null && b != null && b > a) {
                list.add(Pair(a, b))
                saveRanges()
                status.text = "تمت إضافة فترة $name"
            } else status.text = "الصيغة غير صحيحة"
        }
    }

    private fun key(): String {
        val u = videoUri?.toString() ?: return "none"
        return MessageDigest.getInstance("SHA-256").digest(u.toByteArray())
            .joinToString("") { "%02x".format(it) }.take(16)
    }

    private fun enc(l: List<Pair<Long, Long>>) =
        l.joinToString(",") { it.first.toString() + "-" + it.second.toString() }

    private fun dec(s: String): List<Pair<Long, Long>> =
        s.split(",").mapNotNull {
            val p = it.split("-")
            val a = if (p.size == 2) p[0].toLongOrNull() else null
            val b = if (p.size == 2) p[1].toLongOrNull() else null
            if (a != null && b != null) Pair(a, b) else null
        }

    private fun saveRanges() {
        getSharedPreferences("ranges", 0).edit()
            .putString(key() + "s", enc(skipRanges))
            .putString(key() + "c", enc(coverRanges))
            .apply()
    }

    private fun loadRanges() {
        val sp = getSharedPreferences("ranges", 0)
        skipRanges.clear()
        coverRanges.clear()
        skipRanges.addAll(dec(sp.getString(key() + "s", "") ?: ""))
        coverRanges.addAll(dec(sp.getString(key() + "c", "") ?: ""))
    }

    override fun onPause() {
        super.onPause()
        if (!isInPictureInPictureMode) player.pause()
    }

    override fun onDestroy() {
        handler.removeCallbacks(checker)
        player.release()
        super.onDestroy()
    }
}
